﻿using System;

//1

//public static class StringExtensions
//{
//    public static int CountVowels(this string input)
//    {
//        if (string.IsNullOrEmpty(input))
//            return 0;

//        int count = 0;
//        string vowels = "aeiouAEIOU";

//        foreach( char c in input)
//        {
//            if (vowels.Contains(c))
//                count++;
//        }
//        return count;

//    }
//}

//class Program
//{
//    static void Main()
//    {
//        Console.Write("Enter a word: ");
//        string word = Console.ReadLine();
//        Console.WriteLine($"Count: {word.CountVowels()}");
//    }
//}

//2
//public partial class Student
//{
//    public string Name{ get; set; }
//    public int Age{ get; set; }

//    partial void ShowMessage();

//    public void Display()
//    {
//        Console.WriteLine($"Students name and age: {Name},{Age}");
//        ShowMessage();
//    }
//}

//public partial class Student
//{
//    partial void ShowMessage()
//    {
//        Console.WriteLine("Student Information Loaded");
//    }
//}

//public class Program
//{
//    public static void Main()
//    {
//        Student student1 = new Student();

//        Console.Write("Enter students name: ");
//        student1.Name = Console.ReadLine();

//        Console.Write("Enter Students age: ");
//        string ageInput = Console.ReadLine();
//        student1.Age = int.Parse(ageInput);

//        student1.Display();
//    }
//}

//3
//public static class TemperatureConverter
//{
//    public static double CelsiusToFahrenheit(double c)
//    {
//        return (c * 9 / 5) + 32;
//    }

//    public static double FahrenheitToCelsius(double f)
//    {
//        return (f - 32) * 5 / 9;
//    }
//}

//public class Program
//{
//    public static void Main()
//    {
//        Console.Write("Enter temperature: ");
//        double temp = double.Parse(Console.ReadLine());

//        Console.Write("Enter C (C->F) or F(F->C): ");
//        string type = Console.ReadLine().ToUpper();

//        if (type == "C")
//        {
//            double result = TemperatureConverter.CelsiusToFahrenheit(temp);
//            Console.WriteLine($"Fahrenheit: {result}");
//        }
//        else if (type == "F")
//        {
//            double result = TemperatureConverter.FahrenheitToCelsius(temp);
//            Console.WriteLine($"Celsius: {result}");
//        }
//        else
//        {
//            Console.WriteLine("please enter 'C' or 'F'.");
//        }
//    }
//}
