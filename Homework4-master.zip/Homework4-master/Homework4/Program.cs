﻿using System;

//1
//public class Student
//{
//    public string Name { get; set; }
//    public int Age { get; set; }

//    public Student(string name, int age)
//    {
//        Name = name;
//        Age = age;

//    }

//    public void ShowInfo()
//    {
//        Console.WriteLine($"Students name and age: {Name} ,{Age}");
//    }

//}

//class Program
//{
//    static void Main()
//    {
//        Student student1 = new Student("Barbare", 19);
//        student1.ShowInfo();
//    }
//}

//2
//public class Car
//{
//    public string Brand { get; set; }
//    public int Year { get; set; }

//    public Car(string brand , int year)
//    {
//        Brand = brand;
//        Year = year;
//    }

//    public void ShowInfo()
//    {
//        Console.WriteLine($"Cars brand and year: {Brand} ,{Year}");
//    }
//}

//class Program
//{
//    static void Main()
//    {
//        Car car1 = new Car("mercedes", 1995);
//        car1.ShowInfo();
//    }
//}

//3
//public struct Rectangle
//{
//    public double Width { get; set; }
//    public double Height { get; set; }

//    public Rectangle(double width , double height)
//    {
//        Width = width;
//        Height = height;
//    }

//    public double GetArea()
//    {
//        return Width * Height;
//    }
//}

//class Program
//{
//    static void Main()
//    {
//        Rectangle rectangle1 = new Rectangle(10, 3);
//        double area = rectangle1.GetArea();

//        Console.WriteLine($"Area: {area}");
//    }
//}

//4
//namespace School
//{
//    public class Teacher
//    {
//        public string Name{ get; set; }
//        public string Subject{ get; set; }

//        public Teacher(string name , String subject)
//        {
//            Name = name;
//            Subject = subject;
//        }
//    }

//}
//class Program
//{
//    static void Main()
//    {
//        School.Teacher teacher = new School.Teacher("Mariami", "matematika");

//        Console.WriteLine($"Name and Subject: {teacher.Name} , {teacher.Subject}");   
//    }
//}

//5
//public enum OrderStatus
//{
//    Pending,
//    Approved,
//    Rejected
//}

//class Program
//{
//    static void Main()
//    {
//        OrderStatus currentStatus = OrderStatus.Pending;

//        Console.WriteLine($"status: {currentStatus}");

//        Console.WriteLine($"index: {(int)currentStatus}");
//    }
//}

//6
//public class Calculator
//{
//    public static double Add(double a , double b)
//    {
//        return a + b;
//    }

//    public static double Multiply(double a, double b)
//    {
//        return a * b;
//    }
//}

//class Program
//{
//    static void Main()
//    {
//        double sum = Calculator.Add(10, 7);
//        double multyply = Calculator.Multiply(10, 7);

//        Console.WriteLine($"Sum: {sum}");
//        Console.WriteLine($"namravli: {multyply}");
//    }
//}

