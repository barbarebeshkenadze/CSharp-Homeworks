﻿using System;

//1
//class Program
//{
//    static void Main()
//    {
//        int[,] numbers =
//        {
//            { 1 , 2 , 3 },
//            {4, 5 , 6 }
//        };

//        int rows = numbers.GetLength(0);
//        int columns = numbers.GetLength(1);

//        for (int i = 0; i < rows; i++)
//        {
//            for (int j = 0; j < columns; j++)
//            {
//                Console.Write(numbers[i, j] + " ");
//            }

//            Console.WriteLine();
//        }
//    }
//}

//2
//class Program
//{
//    static void Main()
//    {
//        int[,] numbers =
//        {
//            {10 , 20},
//            {30, 40}
//        };

//        int sum = 0;

//        for (int i = 0; i < numbers.GetLength(0); i++)
//        {
//            for (int j =0; j < numbers.GetLength(1); j++)
//            {
//                sum += numbers[i, j];
//            }
//        }

//        Console.WriteLine($"Sum: {sum}");
//    }
//}

//3
//class Program
//{
//    static void Main()
//    {
//        int[,] numbers =
//        {
//            {15,7,20},
//            {40,12,8}
//        };

//        int max = numbers[0, 0];

//        for (int i = 0; i < numbers.GetLength(0); i++)
//        {
//            for (int j = 0; j < numbers.GetLength(1); j++)
//            {
//                if (numbers[i,j] > max)
//                {
//                    max = numbers[i, j];
//                }
//            }
//        }

//        Console.WriteLine($"Max: {max}");
//    }
//}

//4
//class Program
//{
//    static void Main()
//    {
//        int[,] numbers =
//        {
//            {2,5,8},
//            {7,10,3}
//        };

//        int count = 0;

//        for (int i = 0; i < numbers.GetLength(0); i++)
//        {
//            for (int j = 0; j < numbers.GetLength(1); j++)
//            {
//                if (numbers[i, j] % 2 == 0)
//                {
//                    count++;
//                }
//            }
//        }

//        Console.WriteLine($"Even count: {count}");
//    }
//}