﻿using System;

//1
//class Program
//{
//    static void Main()
//    {
//        Console.WriteLine("Enter number: ");
//        int num = int.Parse(Console.ReadLine());

//        string result = (num % 2 == 0) ? "even number" : "odd number";

//        Console.WriteLine(result);
//    }
//}


//2
//class Program
//{
//    static int NameLength(string input)
//    {
//        return input.Length;
//    }
//    static void Main()
//    {
//        Console.WriteLine("Enter your name: ");
//        string name = Console.ReadLine();

//        int count = NameLength(name);

//        Console.WriteLine("name length: " + count);
//    }
//}



//3
//class Program
//{
//    static void Main()
//    {
//        Console.WriteLine("Enter your name: ");
//        string name = Console.ReadLine();

//        Console.WriteLine($"Name: {name}");
//        Console.WriteLine($"Upper: {name.ToUpper()}");
//        Console.WriteLine($"Lower: {name.ToLower()}");
//        Console.WriteLine($"Lenght: {name.Length}");
//        Console.WriteLine($"Contains: {name.ToLower().Contains("a")}");


//    }
//}
