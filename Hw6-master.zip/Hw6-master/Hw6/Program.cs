﻿using System;

namespace Hw6
{
    class Program
    {
        static void Main()
        {
            //1

            Console.WriteLine("Enter numbers for average:");
            Console.WriteLine("Enter number 1: ");
            double number1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter number 2: ");
            double number2 = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter number 3: ");
            double number3 = double.Parse(Console.ReadLine());

            double res = Average.CalculateAverage(number1, number2, number3);
            Console.WriteLine($"Average = {res}");

            //2
            Console.WriteLine("Enter numbers for swap: ");
            Console.WriteLine("Enter a:");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter b: ");
            int b = int.Parse(Console.ReadLine());

            Console.WriteLine($"before: {a},{b}");
            Swap.SwapNumbers(ref a, ref b);
            Console.WriteLine($"after: {a},{b}");

            //3
            //???
        }
    }
}