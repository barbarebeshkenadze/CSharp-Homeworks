﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hw6
{
    internal class BankAccount
    {
        /////?????
    }
}
