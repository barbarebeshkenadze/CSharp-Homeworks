﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hw6
{
    internal class Swap
    {
        public static void SwapNumbers(ref int x , ref int y)
        {
            int temp = x;
            x = y;
            y = temp;
        }
    }
}
