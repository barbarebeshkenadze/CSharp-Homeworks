﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hw6
{
    internal class Average
    {
        public static double CalculateAverage(double a , double b , double c)
        {
            return (a + b + c) / 3;
        }
    }
}
